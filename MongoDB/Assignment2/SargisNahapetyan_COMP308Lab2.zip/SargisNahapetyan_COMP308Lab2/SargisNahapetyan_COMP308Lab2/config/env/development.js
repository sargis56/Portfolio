﻿module.exports = {
    db: 'mongodb://localhost/mean-book',
    sessionSecret: "developmentSessionSecret"
}