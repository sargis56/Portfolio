﻿exports.render = function (request, response) {

    response.render('thankyou');

};