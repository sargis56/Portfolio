﻿module.exports = {
    sessionSecret: "developmentSessionSecret"
}