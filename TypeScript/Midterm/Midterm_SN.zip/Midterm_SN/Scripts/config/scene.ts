module config {
    export enum Scene {
        START,
        GAME,
        OVER
    }
}