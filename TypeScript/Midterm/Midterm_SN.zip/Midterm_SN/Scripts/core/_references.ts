/// <reference path="../../Scripts/objects/game.ts"/>
/// <reference path="../../Scripts/objects/label.ts"/>
/// <reference path="../../Scripts/objects/button.ts"/>
/// <reference path="../../Scripts/config/scene.ts"/>
/// <reference path="../../Scripts/objects/scene.ts"/>
/// <reference path="../../Scripts/objects/sprite.ts"/>

/// <reference path="../../Scripts/scenes/gameover.ts"/>
/// <reference path="../../Scripts/scenes/play.ts"/>
/// <reference path="../../Scripts/scenes/start.ts"/>